#ifndef BUILDING_H
#define BUILDING_H
#include"LTexture.h"

class Building
{
    public:
        Building(LTexture*);
        ~Building();
        void IncreaseX();
        void DecreaseX();
        void Render(SDL_Renderer*);
        SDL_Rect camera;
    private:
        LTexture* buildingTexture;
        int buildingVelocity = 4;
};

#endif // BUILDING_H
