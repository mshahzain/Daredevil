#ifndef PLAYER_H
#define PLAYER_H
#include <SDL.h>
#include <SDL_image.h>
#include"LTexture.h"
#include"Character.h"
#include"Point.h"
#include"Health.h"
#pragma once

class Player:public Character
{
  private:
      Player(LTexture*);
      static Player* instance;
      bool rage;
      int rageMeter;
      LTexture* playerTexture;
      SDL_Rect spriteClips[23];
      SDL_Rect punchClips[30];
      SDL_Rect fallClips[31];
      SDL_Rect kickClips[21];
      SDL_Rect jumpClips[22];
      int moveFrame = 0;
      int punchFrame = 0;
      int fallFrame = 0;
      int kickFrame = 0;
      int jumpFrame = 0;
      int health;


  public:

    ~Player();
    static Player* getInstance(LTexture*);
    void render(SDL_Renderer*);
    void MoveArrayMaker();
    void PunchArrayMaker();
    void FallArrayMaker();
    void JumpArrayMaker();
    int playerVelocity;
    int jumpHeight;
    void Move(SDL_Renderer*,const double, SDL_RendererFlip);
    void Punch(SDL_Renderer*,const double,SDL_RendererFlip);
    void Fall(SDL_Renderer*,const double, SDL_RendererFlip);
    void StandStill(SDL_Renderer*,const double, SDL_RendererFlip);
    void AfterFall(SDL_Renderer*, const double, SDL_RendererFlip);
    void KickArrayMaker();
    void Kick(SDL_Renderer*,const double, SDL_RendererFlip);
    void Jump(SDL_Renderer*, const double, SDL_RendererFlip);
    bool key_right = false;
    bool key_left = false;
    bool key_w = false;
    bool key_l = false;
    bool key_s = false;
    bool key_a = false;
    bool fallen = false;
    bool turned_left = false;
    Health* healthBar = NULL;

    void ActivateRage();

};

#endif // PLAYER_H
