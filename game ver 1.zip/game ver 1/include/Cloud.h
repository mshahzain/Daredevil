#ifndef CLOUD_H
#define CLOUD_H
#include"LTexture.h"

class Cloud
{
    public:
        Cloud(LTexture*);
        ~Cloud();
        void Render(SDL_Renderer*, SDL_Rect);
    private:
        SDL_Rect srcRect;
        LTexture* cloudTexture;
};

#endif // CLOUD_H
