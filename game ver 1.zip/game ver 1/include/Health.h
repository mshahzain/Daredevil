#ifndef HEALTH_H
#define HEALTH_H
#include <SDL.h>
#include <SDL_image.h>

class Health
{
private:
    SDL_Rect outerRect;
    SDL_Rect innerRect;

    int health;
    int healthDecrement;
    int healthIncrement;

public:
    Health();
    void DecreaseHealth();
    void IncreaseHealth();
    void Render(SDL_Renderer*);
};

#endif // HEALTH_H
