#ifndef MAINGAME_H
#define MAINGAME_H
#include <iostream>
#include <stdio.h>
#include <string>
#include <SDL.h>
#include <SDL_image.h>
#include "LTexture.h"
#include"Cloud.h"
#include"Player.h"
#include"Health.h"
#include"Background.h"
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;

class MainGame
{
    public:
        ~MainGame();
        void init(const char*, int xpos, int ypos, int width, int height, LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
        void handleEvents();
        void update();
        void render();
        void clean();
        bool Running();
        static MainGame* getInstance(const char*, int xpos, int ypos, int width, int height, LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
    protected:

    private:
        MainGame(const char*, int xpos, int ypos, int width, int height, LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
        static MainGame* instance;
        int count = 0;
        bool isRunning;
        int mountainVelocity = 2;
        int foregroundVelocity = 4;
        int x = 0;
        SDL_Rect cloud1Camera;
        SDL_Rect cloud2Camera;
        SDL_Rect foregroundRect;
        SDL_Rect sr1 = {7647-SCREEN_WIDTH,0,640,720};
        SDL_Rect dr1 = {0,0,640,720};
        SDL_Rect sr2 = {0,0,640,720};
        SDL_Rect dr2 = {640,0,640,720};
        //SDL_Texture* texture;
        SDL_Window* window = NULL;
        SDL_Renderer* renderer = NULL;
        SDL_Rect* camera = NULL;
        SDL_Event e;
        const Uint8 *keystate = SDL_GetKeyboardState(NULL);
        Player* newPlayer = NULL;
        Background* mountain = NULL;
        Background* foreground1 = NULL;
        Background* foreground2 = NULL;
        bool background1 = true;
        bool background2 = false;


};

#endif // MAINGAME_H
