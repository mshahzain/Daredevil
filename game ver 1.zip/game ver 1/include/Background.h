#ifndef BACKGROUND_H
#define BACKGROUND_H
#include <SDL.h>
#include <SDL_image.h>
#include"LTexture.h"

class Background
{
    public:
        Background(LTexture*);
        ~Background();
        void Render(SDL_Renderer*, SDL_Rect*,SDL_Rect*);
        bool backgroundUsed;
    private:
        LTexture* backgroundTexture;

};

#endif // BACKGROUND_H
