#include "MainGame.h"
MainGame* MainGame::instance = NULL;
bool clouds_render = false;
Cloud* cloud1 = NULL;
Cloud* cloud2 = NULL;

MainGame::MainGame(const char* gameTitle, int xpos, int ypos, int width, int height, LTexture* mountainTexture, LTexture* foregroundTexture1, LTexture* foregroundTexture2, LTexture* heroTexture, LTexture* clouds)
{
    MainGame::init(gameTitle, xpos,ypos,width,height,mountainTexture, foregroundTexture1, foregroundTexture2, heroTexture, clouds);
}

MainGame::~MainGame()
{
    delete instance;
}



MainGame* MainGame::getInstance(const char* gameTitle, int xpos, int ypos, int width, int height, LTexture* mountainTexture, LTexture* foregroundTexture1, LTexture* foregroundTexture2, LTexture* heroTexture, LTexture* clouds  )
{
    if (instance == NULL)
    {
        instance = new MainGame(gameTitle, xpos,ypos,width,height,mountainTexture, foregroundTexture1, foregroundTexture2, heroTexture, clouds);
    }
    return instance;
}

void MainGame::init(const char* gameTitle, int xpos, int ypos, int width, int height, LTexture* mountainTexture, LTexture* foregroundTexture1, LTexture* foregroundTexture2, LTexture* heroTexture, LTexture* clouds)
{
    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        std::cout << "Subsystems initialized" << std::endl;
        window = SDL_CreateWindow(gameTitle , xpos, ypos, width, height,0);
        if (window)
        {
            std::cout << "window created" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 0xFF,0xFF,0xFF,0xFF);
            std::cout << "Renderer created" << std::endl;
        }
        isRunning = true;
    cloud1 = new Cloud(clouds);
    cloud2 = new Cloud(clouds);

    mountainTexture -> LoadFromFile(renderer, "C:/Users/User/Desktop/OOP GAME 1/OOP Project Graphics/GameBackground mountains.png");
    heroTexture -> LoadFromFile(renderer, "C:/Users/User/Desktop/OOP GAME 1/OOP Project Graphics/Main_Hero_Sheets.png");
    foregroundTexture1 -> LoadFromFile(renderer, "C:/Users/User/Desktop/OOP GAME 1/OOP Project Graphics/ForegroundPiece_1.png");
    foregroundTexture2 -> LoadFromFile(renderer, "C:/Users/User/Desktop/OOP GAME 1/OOP Project Graphics/ForegroundPiece_2_Place at 7674.png");
    clouds -> LoadFromFile(renderer, "C:/Users/User/Desktop/OOP GAME 1/OOP Project Graphics/clouds.png");
    newPlayer = Player::getInstance(heroTexture);
    mountain = new Background(mountainTexture);
    foreground1 = new Background(foregroundTexture1);
    foreground2 = new Background(foregroundTexture2);
    foreground1->backgroundUsed = true;
    foreground2 -> backgroundUsed = false;
    camera = new SDL_Rect;
    camera->x = 0;
    camera->y = 0;
    camera->w = 1280;
    camera->h = 720;

    foregroundRect.x = 0;
    foregroundRect.y = 0;
    foregroundRect.w = 1280;
    foregroundRect.h = 720;

    cloud1Camera.x = 0;
    cloud1Camera.y = 40;
    cloud1Camera.w = 100;
    cloud1Camera.h = 50;

    cloud2Camera.x = -100;
    cloud2Camera.y = 60;
    cloud2Camera.w = 100;
    cloud2Camera.h = 50;



    }
    else
        isRunning = false;
}
//Player* newPlayer = Player::getInstance();
void MainGame::handleEvents()
{

    //previousY = newPlayer->position->getY();
    SDL_PollEvent(&e);
    if (e.type == SDL_QUIT)
        isRunning = false;
    switch (e.type)
    {
    case SDL_KEYDOWN:

        if (e.key.keysym.sym == SDLK_RIGHT && !newPlayer->fallen)
        {
            if (newPlayer->position->getX() >= SCREEN_WIDTH/2)
            {
                camera -> x += mountainVelocity;
                foregroundRect.x += foregroundVelocity;
                if (foreground1->backgroundUsed && !foreground2->backgroundUsed)
                {
                    if (foregroundRect.x >= 7647-SCREEN_WIDTH)
                    {
                        foreground2->backgroundUsed = true;
                        foreground1->backgroundUsed = false;

                        foregroundRect.x = 0;
                    }
                }
                if (foreground2->backgroundUsed && foreground1->backgroundUsed)
                {
                    if (foregroundRect.x >= 7037 - SCREEN_WIDTH)
                    {
                        foreground1->backgroundUsed = true;
                        foreground2->backgroundUsed = false;
                        foregroundRect.x = 0;
                    }
                }

            }
            //camera -> x += newPlayer.playerVelocity;
            else
            {
                newPlayer -> position->setX(newPlayer->position->getX() + newPlayer->playerVelocity);
            }
            //newPlayer.position->setX(newPlayer.position->getX() + newPlayer.playerVelocity);
            newPlayer->key_right = true;
            newPlayer->turned_left = false;
            break;
        }
        if (e.key.keysym.sym == SDLK_LEFT && !newPlayer->fallen)
        {
            if (newPlayer->position->getX() >= SCREEN_WIDTH/2)
            {

                camera -> x -= mountainVelocity;
                foregroundRect.x -= foregroundVelocity;

                if (foregroundRect.x <= 0 && foreground2->backgroundUsed)
                {
                    foreground1->backgroundUsed = true;
                    foreground2->backgroundUsed = false;
                    foregroundRect.x = 7674 - SCREEN_WIDTH;
                }
                if (foregroundRect.x <= 0 && foreground1->backgroundUsed)
                {
                   foregroundRect.x = 0;
                   newPlayer->position->setX(newPlayer->position->getX() - newPlayer->playerVelocity);
                   if (newPlayer->position -> getX() < 0)
                   {
                     newPlayer->position->setX(0);
                   }
                }
            }
            //camera -> x -= newPlayer.playerVelocity;

            else
            {
                newPlayer->position->setX(newPlayer->position->getX() - newPlayer->playerVelocity);
                if (newPlayer->position -> getX() < 0)
                {
                    newPlayer->position->setX(0);
                }
            }
            //newPlayer.position->setX(newPlayer.position->getX() - newPlayer.playerVelocity);
            newPlayer->key_left = true;
            newPlayer->turned_left = true;
            break;
         //newPlayer.Move(renderer);
        }

        if (e.key.keysym.sym == SDLK_w && !newPlayer->fallen)
        {
            newPlayer->key_w = true;
            break;
        }

        if (e.key.keysym.sym == SDLK_l && !newPlayer->fallen)
        {
            newPlayer->key_l = true;
            newPlayer->fallen = true;
            break;
        }
        if (e.key.keysym.sym == SDLK_s && !newPlayer->fallen)
        {
            newPlayer->key_s = true;
            break;
        }
        if (e.key.keysym.sym == SDLK_a && !newPlayer->fallen)
        {
            newPlayer->key_a = true;
            break;
            //previousY = newPlayer->position->getY();
            //newPlayer->position->setY(newPlayer->position->getY() - newPlayer->jumpHeight);
        }

    case SDL_KEYUP:
        if (e.key.keysym.sym == SDLK_w && !newPlayer->fallen)
        {
            newPlayer->key_w = false;
            break;

        }
        if (e.key.keysym.sym == SDLK_LEFT)
        {
            newPlayer->key_left = false;
            break;
        }
        if (e.key.keysym.sym == SDLK_RIGHT)
        {
            newPlayer->key_right = false;
            break;
        }
        if (e.key.keysym.sym == SDLK_l && !newPlayer->fallen)
        {
            newPlayer->key_l = false;
            newPlayer->fallen = true;
            break;
        }
        if (e.key.keysym.sym == SDLK_s && !newPlayer->fallen)
        {
            newPlayer->key_s = false;
            break;
        }
        if (e.key.keysym.sym == SDLK_a && !newPlayer->fallen)
        {
            newPlayer->key_a = false;
            break;
            //newPlayer->position->setY(previousY);
        }

    }
    //SDL_FlushEvent(e.type);
    //cout << SDL_PollEvent(&e) << endl;



}


void MainGame::update()
{
    SDL_RenderClear(renderer);
cout << newPlayer->key_s << endl;


    mountain -> Render(renderer,camera,NULL);

    if (foreground1->backgroundUsed && !foreground2->backgroundUsed)
    {
        foreground1 -> Render(renderer, &foregroundRect, NULL);
    }
    if(foreground2->backgroundUsed && !foreground1->backgroundUsed)
    {
        foreground2 -> Render(renderer, &foregroundRect,NULL);
    }



    //tex1 -> Render(renderer,camera, NULL);
    //tex1 -> Render(renderer,camera, NULL);
    cloud1 -> Render(renderer, cloud1Camera);
    //cloud2 -> Render(renderer,cloud2Camera);
    cloud1Camera.x += 1;
    if (cloud1Camera.x >= 1280)
    {
        cloud1Camera.x = -100;
    }
    if (cloud1Camera.x >= SCREEN_WIDTH/2)
    {
        cloud2 -> Render(renderer, cloud2Camera);
        clouds_render = true;
    }
    if (clouds_render)
    {
        cloud2Camera.x += 1;
        if (cloud2Camera.x >= 1280)
        {
            clouds_render = false;
        }
    }
    newPlayer->healthBar-> Render(renderer);



    if (!newPlayer->fallen && newPlayer->key_right == true)
    {
        newPlayer->Move(renderer, 0 , SDL_FLIP_NONE);
        //key_right = false;
    }
    else if (!newPlayer->fallen && newPlayer->key_left)
    {
        newPlayer->Move(renderer, 360 , SDL_FLIP_HORIZONTAL);
        //key_left = false;
    }
    else if (!newPlayer->fallen && newPlayer->key_w == true && newPlayer->turned_left == true)
    {
        //key_w = false;
        newPlayer->Punch(renderer, 360, SDL_FLIP_HORIZONTAL);
        //newPlayer->key_w = false;
    }
    else if (!newPlayer->fallen && newPlayer->key_w == true && newPlayer->turned_left == false)
    {

        newPlayer->Punch(renderer, 0, SDL_FLIP_NONE);
        //newPlayer->key_w = false;

    }
    else if (!newPlayer->fallen && newPlayer->key_l == true && newPlayer->turned_left == true)
    {

        newPlayer->Fall(renderer,360,SDL_FLIP_HORIZONTAL);
        //newPlayer->key_l = false;

    }
    else if (!newPlayer->fallen && newPlayer->key_l == true && newPlayer->turned_left == false)
    {

        newPlayer->Fall(renderer,0,SDL_FLIP_NONE);
        //newPlayer->key_l = false;

    }
    else if (!newPlayer->fallen && newPlayer->key_s == true && newPlayer->turned_left == true)
    {

        newPlayer->Kick(renderer, 360, SDL_FLIP_HORIZONTAL);
        //newPlayer->key_s = false;

    }
    else if (!newPlayer->fallen && newPlayer->key_s == true && newPlayer->turned_left == false)
    {

        newPlayer->Kick(renderer,0,SDL_FLIP_NONE);
         //newPlayer->key_s = false;

    }
     else if (!newPlayer->fallen && newPlayer->key_a == true && newPlayer->turned_left == true)
    {

        newPlayer->Jump(renderer, 360, SDL_FLIP_HORIZONTAL);
        //newPlayer->key_a = false;

    }
    else if (!newPlayer->fallen && newPlayer->key_a == true && newPlayer->turned_left == false)
    {

        newPlayer->Jump(renderer,0,SDL_FLIP_NONE);
        //newPlayer->key_a = false;

    }

    else if (!newPlayer->fallen && newPlayer->turned_left == true)
    {
        newPlayer->StandStill(renderer,360,SDL_FLIP_HORIZONTAL);

    }

    else if (!newPlayer->fallen && newPlayer->turned_left == false)
    {
        newPlayer->StandStill(renderer,0,SDL_FLIP_NONE);

    }
    else if (newPlayer->fallen && newPlayer->turned_left == true)
    {
        newPlayer->AfterFall(renderer, 360, SDL_FLIP_HORIZONTAL);
    }
    else if (newPlayer->fallen && newPlayer->turned_left == false)
    {
        newPlayer->AfterFall(renderer, 0, SDL_FLIP_NONE);
    }


cout << newPlayer->key_s << endl;
    //SDL_RenderPresent(renderer);



}

void MainGame::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    std::cout << "Game cleaned" << std::endl;
}

void MainGame::render()
{
    SDL_RenderPresent(renderer);
}

bool MainGame::Running()
{
   return isRunning;
}
