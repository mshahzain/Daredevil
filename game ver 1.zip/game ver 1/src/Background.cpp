#include "Background.h"

Background::Background(LTexture* texture)
{
    backgroundTexture = texture;
}

Background::~Background()
{
    //dtor
}

void Background::Render(SDL_Renderer* renderer, SDL_Rect* srcRect, SDL_Rect* destRect)
{
    backgroundTexture->Render(renderer,srcRect, destRect, 0, SDL_FLIP_NONE);
}
