#include "Character.h"

Character::Character()
{
    //ctor
}

Character::~Character()
{
    //dtor
}

void Character::Move(SDL_Renderer* renderer)
{

}
