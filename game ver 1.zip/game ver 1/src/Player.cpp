#include "Player.h"

const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;
Player* Player::instance = NULL;

Player::Player(LTexture* texture)
{
    playerTexture = texture;
    position = new Point;
    position -> setX(0);
    position -> setY(SCREEN_HEIGHT-352);
    playerVelocity = 5;
    jumpHeight = 120;
    healthBar = new Health;
    PunchArrayMaker();
    MoveArrayMaker();
    FallArrayMaker();
    KickArrayMaker();
    JumpArrayMaker();
}

Player::~Player()
{
    delete instance;
}

Player* Player::getInstance(LTexture* tex)
{
    if (instance == NULL)
    {
        instance = new Player(tex);
    }
    return instance;
}

void Player::MoveArrayMaker()
{
    spriteClips[ 0 ].x =   0;
    spriteClips[ 0 ].y =   0;
    spriteClips[ 0 ].w =  274;
    spriteClips[ 0 ].h = 340;


    spriteClips[ 1 ].x =  274;
    spriteClips[ 1 ].y =   0;
    spriteClips[ 1 ].w =  274;
    spriteClips[ 1 ].h = 340;

    spriteClips[ 2 ].x = 548;
    spriteClips[ 2 ].y =   0;
    spriteClips[ 2 ].w =  274;
    spriteClips[ 2 ].h = 340;

    spriteClips[ 3 ].x = 822;
    spriteClips[ 3 ].y =   0;
    spriteClips[ 3 ].w =  274;
    spriteClips[ 3 ].h = 340;

    spriteClips[ 4 ].x = 1096;
    spriteClips[ 4 ].y =   0;
    spriteClips[ 4 ].w =  274;
    spriteClips[ 4 ].h = 340;

    spriteClips[ 5 ].x = 1370;
    spriteClips[ 5 ].y =   0;
    spriteClips[ 5 ].w =  274;
    spriteClips[ 5 ].h = 340;

    spriteClips[ 6 ].x = 1644;
    spriteClips[ 6 ].y =   0;
    spriteClips[ 6 ].w =  274;
    spriteClips[ 6 ].h = 340;

    spriteClips[ 7 ].x = 0;
    spriteClips[ 7 ].y = 352;
    spriteClips[ 7 ].w = 274;
    spriteClips[ 7 ].h = 340;

    spriteClips[ 8 ].x = 274;
    spriteClips[ 8 ].y =   352;
    spriteClips[ 8 ].w =  274;
    spriteClips[ 8 ].h = 340;

    spriteClips[ 9 ].x = 548;
    spriteClips[ 9 ].y =   352;
    spriteClips[ 9 ].w =  274;
    spriteClips[ 9 ].h = 340;

    spriteClips[ 10 ].x = 822;
    spriteClips[ 10 ].y =   352;
    spriteClips[ 10 ].w =  274;
    spriteClips[ 10 ].h = 340;

    spriteClips[ 11 ].x = 1096;
    spriteClips[ 11 ].y =   352;
    spriteClips[ 11 ].w =  274;
    spriteClips[ 11 ].h = 340;

    spriteClips[ 12 ].x = 1370;
    spriteClips[ 12 ].y =   352;
    spriteClips[ 12 ].w =  274;
    spriteClips[ 12 ].h = 340;

    spriteClips[ 13 ].x = 1644;
    spriteClips[ 13 ].y =   352;
    spriteClips[ 13 ].w =  274;
    spriteClips[ 13 ].h = 340;

    spriteClips[ 14 ].x = 0;
    spriteClips[ 14 ].y = 704;
    spriteClips[ 14 ].w = 274;
    spriteClips[ 14 ].h = 340;

    spriteClips[ 15 ].x = 274;
    spriteClips[ 15 ].y =  704;
    spriteClips[ 15 ].w =  274;
    spriteClips[ 15 ].h = 340;

    spriteClips[ 16 ].x = 548;
    spriteClips[ 16 ].y =  704;
    spriteClips[ 16 ].w =  274;
    spriteClips[ 16 ].h = 340;

    spriteClips[ 17 ].x = 822;
    spriteClips[ 17 ].y =   704;
    spriteClips[ 17 ].w =  274;
    spriteClips[ 17 ].h = 340;

    spriteClips[ 18 ].x = 1096;
    spriteClips[ 18 ].y =   704;
    spriteClips[ 18 ].w =  274;
    spriteClips[ 18 ].h = 340;

    spriteClips[ 19 ].x = 1370;
    spriteClips[ 19 ].y =  704;
    spriteClips[ 19 ].w =  274;
    spriteClips[ 19 ].h = 340;

    spriteClips[ 20 ].x = 1644;
    spriteClips[ 20 ].y =   704;
    spriteClips[ 20 ].w =  274;
    spriteClips[ 20 ].h = 340;

    spriteClips[ 21 ].x = 0;
    spriteClips[ 21 ].y = 1056;
    spriteClips[ 21 ].w = 274;
    spriteClips[ 21 ].h = 340;

    spriteClips[ 22 ].x = 274;
    spriteClips[ 22 ].y =  1056;
    spriteClips[ 22 ].w =  274;
    spriteClips[ 22 ].h = 340;
}

void Player::Move(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{

    SDL_Rect* currentClip = &spriteClips[ moveFrame / 23];

     //Set rendering space and render to screen
    SDL_Rect renderQuad;
    renderQuad.x = position -> getX()-50;
    renderQuad.y = position -> getY() + 120;

    //Set clip rendering dimensions
    if( currentClip != NULL )
    {
        renderQuad.w = 160;
        renderQuad.h = 200;
    }

    //Render to screen
    playerTexture -> Render(renderer,currentClip, &renderQuad , angle, flip);
    //SDL_RenderCopy( renderer, texture1, currentClip, &renderQuad );
    moveFrame = moveFrame +23;
    if (moveFrame /23>= 23)
    {
        moveFrame = 0;

    }
    //SDL_RenderPresent(renderer);
}

void Player::render(SDL_Renderer* renderer)
{

}
void Player::StandStill(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{
    SDL_Rect still,dest;
    still.x = 0;
    still.y = 1463;
    still.w = 180;
    still.h = 352;

    dest.x = position -> getX();
    dest.y = position -> getY() + 120;
    dest.w = 100;
    dest.h = 200;
    //SDL_RenderClear(renderer);

    playerTexture -> Render(renderer, &still, &dest, angle ,flip);
    //SDL_RenderPresent(renderer);

}
void Player::PunchArrayMaker()
{
    punchClips[0].x = 0;
    punchClips[0].y = 1463;
    punchClips[0].w = 318;
    punchClips[0].h = 354;

    punchClips[1].x = 318;
    punchClips[1].y = 1463;
    punchClips[1].w = 318;
    punchClips[1].h = 354;

    punchClips[2].x = 636;
    punchClips[2].y = 1463;
    punchClips[2].w = 318;
    punchClips[2].h = 354;

    punchClips[3].x = 954;
    punchClips[3].y = 1463;
    punchClips[3].w = 318;
    punchClips[3].h = 354;

    punchClips[4].x = 1272;
    punchClips[4].y = 1463;
    punchClips[4].w = 318;
    punchClips[4].h = 354;

    punchClips[5].x = 1590;
    punchClips[5].y = 1463;
    punchClips[5].w = 318;
    punchClips[5].h = 354;

    punchClips[6].x = 0;
    punchClips[6].y = 1817;
    punchClips[6].w = 318;
    punchClips[6].h = 354;

    punchClips[7].x = 318;
    punchClips[7].y = 1817;
    punchClips[7].w = 318;
    punchClips[7].h = 354;

    punchClips[8].x = 636;
    punchClips[8].y = 1817;
    punchClips[8].w = 318;
    punchClips[8].h = 354;

    punchClips[9].x = 954;
    punchClips[9].y = 1817;
    punchClips[9].w = 318;
    punchClips[9].h = 354;

    punchClips[10].x = 1272;
    punchClips[10].y = 1817;
    punchClips[10].w = 318;
    punchClips[10].h = 354;

    punchClips[11].x = 1590;
    punchClips[11].y = 1817;
    punchClips[11].w = 318;
    punchClips[11].h = 354;

    punchClips[12].x = 0;
    punchClips[12].y = 2171;
    punchClips[12].w = 318;
    punchClips[12].h = 354;

    punchClips[13].x = 318;
    punchClips[13].y = 2171;
    punchClips[13].w = 318;
    punchClips[13].h = 354;

    punchClips[14].x = 636;
    punchClips[14].y = 2171;
    punchClips[14].w = 318;
    punchClips[14].h = 354;

    punchClips[15].x = 954;
    punchClips[15].y = 2171;
    punchClips[15].w = 318;
    punchClips[15].h = 354;

    punchClips[16].x = 1272;
    punchClips[16].y = 2171;
    punchClips[16].w = 318;
    punchClips[16].h = 354;

    punchClips[17].x = 1590;
    punchClips[17].y = 2171;
    punchClips[17].w = 318;
    punchClips[17].h = 354;

    punchClips[18].x = 0;
    punchClips[18].y = 2525;
    punchClips[18].w = 318;
    punchClips[18].h = 354;

    punchClips[19].x = 318;
    punchClips[19].y = 2525;
    punchClips[19].w = 318;
    punchClips[19].h = 354;

    punchClips[20].x = 636;
    punchClips[20].y = 2525;
    punchClips[20].w = 318;
    punchClips[20].h = 354;

    punchClips[21].x = 954;
    punchClips[21].y = 2525;
    punchClips[21].w = 318;
    punchClips[21].h = 354;

    punchClips[22].x = 1272;
    punchClips[22].y = 2525;
    punchClips[22].w = 318;
    punchClips[22].h = 354;

    punchClips[23].x = 1590;
    punchClips[23].y = 2525;
    punchClips[23].w = 318;
    punchClips[23].h = 354;

    punchClips[24].x = 0;
    punchClips[24].y = 2879;
    punchClips[24].w = 318;
    punchClips[24].h = 354;

    punchClips[25].x = 318;
    punchClips[25].y = 2879;
    punchClips[25].w = 318;
    punchClips[25].h = 354;

    punchClips[26].x = 636;
    punchClips[26].y = 2879;
    punchClips[26].w = 318;
    punchClips[26].h = 354;

    punchClips[27].x = 954;
    punchClips[27].y = 2879;
    punchClips[27].w = 318;
    punchClips[27].h = 354;

    punchClips[28].x = 1272;
    punchClips[28].y = 2879;
    punchClips[28].w = 318;
    punchClips[28].h = 354;

    punchClips[29].x = 1590;
    punchClips[29].y = 2879;
    punchClips[29].w = 318;
    punchClips[29].h = 354;
}


void Player::Punch(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{

    SDL_Rect* currentClip = &punchClips[ punchFrame / 30];

     //Set rendering space and render to screen
    SDL_Rect renderQuad;
    renderQuad.x = position -> getX();
    renderQuad.y = position -> getY() + 120;

    //Set clip rendering dimensions
    if( currentClip != NULL )
    {
        renderQuad.w = 150;
        renderQuad.h = 200;
    }

    //Render to screen
    playerTexture -> Render(renderer,currentClip, &renderQuad, angle , flip );
    //SDL_RenderCopy( renderer, texture1, currentClip, &renderQuad );
    punchFrame += 30;

    if (punchFrame /30>= 30)
    {
        punchFrame = 0;

    }
    //SDL_RenderPresent(renderer);
}

void Player::FallArrayMaker()
{
    fallClips[0].x = 2850;
    fallClips[0].y = 0;
    fallClips[0].w = 644;
    fallClips[0].h = 362;

    fallClips[1].x = 3494;
    fallClips[1].y = 0;
    fallClips[1].w = 644;
    fallClips[1].h = 362;

    fallClips[2].x = 4138;
    fallClips[2].y = 0;
    fallClips[2].w = 644;
    fallClips[2].h = 362;

    fallClips[3].x = 4782;
    fallClips[3].y = 0;
    fallClips[3].w = 644;
    fallClips[3].h = 362;

    fallClips[4].x = 5426;
    fallClips[4].y = 0;
    fallClips[4].w = 644;
    fallClips[4].h = 362;

    fallClips[5].x = 6070;
    fallClips[5].y = 0;
    fallClips[5].w = 644;
    fallClips[5].h = 362;

    fallClips[6].x = 2850;
    fallClips[6].y = 0;
    fallClips[6].w = 644;
    fallClips[6].h = 362;

    fallClips[7].x = 3494;
    fallClips[7].y = 362;
    fallClips[7].w = 644;
    fallClips[7].h = 362;

    fallClips[8].x = 4138;
    fallClips[8].y = 362;
    fallClips[8].w = 644;
    fallClips[8].h = 362;

    fallClips[9].x = 4782;
    fallClips[9].y = 362;
    fallClips[9].w = 644;
    fallClips[9].h = 362;

    fallClips[10].x = 5426;
    fallClips[10].y = 362;
    fallClips[10].w = 644;
    fallClips[10].h = 362;

    fallClips[11].x = 6070;
    fallClips[11].y = 362;
    fallClips[11].w = 644;
    fallClips[11].h = 362;

    fallClips[12].x = 2850;
    fallClips[12].y = 724;
    fallClips[12].w = 644;
    fallClips[12].h = 362;

    fallClips[13].x = 3494;
    fallClips[13].y = 724;
    fallClips[13].w = 644;
    fallClips[13].h = 362;

    fallClips[14].x = 4138;
    fallClips[14].y = 724;
    fallClips[14].w = 644;
    fallClips[14].h = 362;

    fallClips[15].x = 4782;
    fallClips[15].y = 724;
    fallClips[15].w = 644;
    fallClips[15].h = 362;

    fallClips[16].x = 5426;
    fallClips[16].y = 724;
    fallClips[16].w = 644;
    fallClips[16].h = 362;

    fallClips[17].x = 6070;
    fallClips[17].y = 724;
    fallClips[17].w = 644;
    fallClips[17].h = 362;

    fallClips[18].x = 2850;
    fallClips[18].y = 1086;
    fallClips[18].w = 644;
    fallClips[18].h = 362;

    fallClips[19].x = 3494;
    fallClips[19].y = 1086;
    fallClips[19].w = 644;
    fallClips[19].h = 362;

    fallClips[20].x = 4138;
    fallClips[20].y = 1086;
    fallClips[20].w = 644;
    fallClips[20].h = 362;

    fallClips[21].x = 4782;
    fallClips[21].y = 1086;
    fallClips[21].w = 644;
    fallClips[21].h = 362;

    fallClips[22].x = 5426;
    fallClips[22].y = 1086;
    fallClips[22].w = 644;
    fallClips[22].h = 362;

    fallClips[23].x = 6070;
    fallClips[23].y = 1086;
    fallClips[23].w = 644;
    fallClips[23].h = 362;

    fallClips[24].x = 2850;
    fallClips[24].y = 1448;
    fallClips[24].w = 644;
    fallClips[24].h = 362;

    fallClips[25].x = 3494;
    fallClips[25].y = 1448;
    fallClips[25].w = 644;
    fallClips[25].h = 362;

    fallClips[26].x = 4138;
    fallClips[26].y = 1448;
    fallClips[26].w = 644;
    fallClips[26].h = 362;

    fallClips[27].x = 4782;
    fallClips[27].y = 1448;
    fallClips[27].w = 644;
    fallClips[27].h = 362;

    fallClips[28].x = 5426;
    fallClips[28].y = 1448;
    fallClips[28].w = 644;
    fallClips[28].h = 362;

    fallClips[29].x = 6070;
    fallClips[29].y = 1448;
    fallClips[29].w = 644;
    fallClips[29].h = 362;

    fallClips[30].x = 2850;
    fallClips[30].y = 1810;
    fallClips[30].w = 644;
    fallClips[30].h = 362;
}


void Player::Fall(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{
     SDL_Rect* currentClip = &fallClips[ fallFrame / 31];

     //Set rendering space and render to screen
    SDL_Rect renderQuad;
    renderQuad.x = position -> getX();
    renderQuad.y = position -> getY() + 120;

    //Set clip rendering dimensions
    if( currentClip != NULL )
    {
        renderQuad.w = 100;
        renderQuad.h = 200;
    }

    //Render to screen
    playerTexture -> Render(renderer,currentClip, &renderQuad,angle,flip );
    //SDL_RenderCopy( renderer, texture1, currentClip, &renderQuad );
    fallFrame = fallFrame + 31  ;
    if (fallFrame /31>= 31)
    {
        fallFrame = 0;

    }
    //SDL_RenderPresent(renderer);
}

void Player::AfterFall(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{
    SDL_Rect load;
    load.x = 2850;
    load.y = 1810;
    load.w = 644;
    load.h = 362;

    SDL_Rect renderQuad;
    renderQuad.x = position -> getX();
    renderQuad.y = position -> getY() + 120;
    renderQuad.w = 300;
    renderQuad.h = 200;

    playerTexture -> Render(renderer, &load, &renderQuad,angle,flip);
}

void Player::KickArrayMaker()
{
    kickClips[0].x = 0;
    kickClips[0].y = 3255;
    kickClips[0].w = 212;
    kickClips[0].h = 349;

    kickClips[1].x = 380;
    kickClips[1].y = 3255;
    kickClips[1].w = 220;
    kickClips[1].h = 349;

    kickClips[2].x = 760;
    kickClips[2].y = 3255;
    kickClips[2].w = 224;
    kickClips[2].h = 349;

    kickClips[3].x = 1140;
    kickClips[3].y = 3255;
    kickClips[3].w = 220;
    kickClips[3].h = 349;

    kickClips[4].x = 1520;
    kickClips[4].y = 3255;
    kickClips[4].w = 216;
    kickClips[4].h = 349;

    kickClips[5].x = 0;
    kickClips[5].y = 3604;
    kickClips[5].w = 230;
    kickClips[5].h = 349;

    kickClips[6].x = 380;
    kickClips[6].y = 3604;
    kickClips[6].w = 276;
    kickClips[6].h = 349;

    kickClips[7].x = 760;
    kickClips[7].y = 3604;
    kickClips[7].w = 276;
    kickClips[7].h = 349;

    kickClips[8].x = 1140;
    kickClips[8].y = 3604;
    kickClips[8].w = 340;
    kickClips[8].h = 349;

    kickClips[9].x = 1520;
    kickClips[9].y = 3604;
    kickClips[9].w = 366;
    kickClips[9].h = 349;

    kickClips[10].x = 0;
    kickClips[10].y = 3953;
    kickClips[10].w = 332;
    kickClips[10].h = 349;

    kickClips[11].x = 380;
    kickClips[11].y = 3953;
    kickClips[11].w = 284;
    kickClips[11].h = 349;

    kickClips[12].x = 760;
    kickClips[12].y = 3953;
    kickClips[12].w = 250;
    kickClips[12].h = 349;

    kickClips[13].x = 1140;
    kickClips[13].y = 3953;
    kickClips[13].w = 246;
    kickClips[13].h = 349;

    kickClips[14].x = 1520;
    kickClips[14].y = 3953;
    kickClips[14].w = 242;
    kickClips[14].h = 349;

    kickClips[15].x = 0;
    kickClips[15].y = 4302;
    kickClips[15].w = 236;
    kickClips[15].h = 349;

    kickClips[16].x = 380;
    kickClips[16].y = 4302;
    kickClips[16].w = 226;
    kickClips[16].h = 349;

    kickClips[17].x = 760;
    kickClips[17].y = 4302;
    kickClips[17].w = 218;
    kickClips[17].h = 349;

    kickClips[18].x = 1140;
    kickClips[18].y = 4302;
    kickClips[18].w = 210;
    kickClips[18].h = 349;

    kickClips[19].x = 1520;
    kickClips[19].y = 4302;
    kickClips[19].w = 209;
    kickClips[19].h = 349;

    kickClips[20].x = 0;
    kickClips[20].y = 4651;
    kickClips[20].w = 208;
    kickClips[20].h = 349;



}


void Player::Kick(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{
     SDL_Rect* currentClip = &kickClips[ kickFrame / 21];

     //Set rendering space and render to screen
    SDL_Rect renderQuad;
    renderQuad.x = position -> getX();
    renderQuad.y = position -> getY() + 120;

    //Set clip rendering dimensions
    if( currentClip != NULL )
    {
        renderQuad.w = 150;
        renderQuad.h = 200;
    }

    //Render to screen
    playerTexture -> Render(renderer,currentClip, &renderQuad, angle , flip );
    //SDL_RenderCopy( renderer, texture1, currentClip, &renderQuad );
    kickFrame = kickFrame + 19;
    if (kickFrame /21>= 21)
    {
        kickFrame = 0;

    }
    //SDL_RenderPresent(renderer);
}

void Player::JumpArrayMaker()
{
    jumpClips[0].x = 0;
    jumpClips[0].y = 5050;
    jumpClips[0].w = 236;
    jumpClips[0].h = 349;

    jumpClips[1].x = 236;
    jumpClips[1].y = 5050;
    jumpClips[1].w = 236;
    jumpClips[1].h = 349;

    jumpClips[2].x = 472;
    jumpClips[2].y = 5050;
    jumpClips[2].w = 236;
    jumpClips[2].h = 349;

    jumpClips[3].x = 708;
    jumpClips[3].y = 5050;
    jumpClips[3].w = 236;
    jumpClips[3].h = 349;

    jumpClips[4].x = 944;
    jumpClips[4].y = 5050;
    jumpClips[4].w = 236;
    jumpClips[4].h = 349;

    jumpClips[5].x = 1180;
    jumpClips[5].y = 5050;
    jumpClips[5].w = 236;
    jumpClips[5].h = 349;

    jumpClips[6].x = 1416;
    jumpClips[6].y = 5050;
    jumpClips[6].w = 236;
    jumpClips[6].h = 349;

    jumpClips[7].x = 1652;
    jumpClips[7].y = 5050;
    jumpClips[7].w = 236;
    jumpClips[7].h = 349;

    jumpClips[8].x = 0;
    jumpClips[8].y = 5424;
    jumpClips[8].w = 236;
    jumpClips[8].h = 349;

    jumpClips[9].x = 236;
    jumpClips[9].y = 5424;
    jumpClips[9].w = 236;
    jumpClips[9].h = 349;

    jumpClips[10].x = 472;
    jumpClips[10].y = 5424;
    jumpClips[10].w = 236;
    jumpClips[10].h = 349;

    jumpClips[11].x = 708;
    jumpClips[11].y = 5424;
    jumpClips[11].w = 236;
    jumpClips[11].h = 349;

    jumpClips[12].x = 944;
    jumpClips[12].y = 5424;
    jumpClips[12].w = 236;
    jumpClips[12].h = 349;

    jumpClips[13].x = 1180;
    jumpClips[13].y = 5424;
    jumpClips[13].w = 236;
    jumpClips[13].h = 349;

    jumpClips[14].x = 1416;
    jumpClips[14].y = 5424;
    jumpClips[14].w = 236;
    jumpClips[14].h = 349;

    jumpClips[15].x = 1652;
    jumpClips[15].y = 5424;
    jumpClips[15].w = 236;
    jumpClips[15].h = 349;

    jumpClips[16].x = 0;
    jumpClips[16].y = 5798;
    jumpClips[16].w = 236;
    jumpClips[16].h = 349;

    jumpClips[17].x = 236;
    jumpClips[17].y = 5798;
    jumpClips[17].w = 236;
    jumpClips[17].h = 349;

    jumpClips[18].x = 472;
    jumpClips[18].y = 5798;
    jumpClips[18].w = 236;
    jumpClips[18].h = 349;

    jumpClips[19].x = 708;
    jumpClips[19].y = 5798;
    jumpClips[19].w = 236;
    jumpClips[19].h = 349;

    jumpClips[20].x = 944;
    jumpClips[20].y = 5798;
    jumpClips[20].w = 236;
    jumpClips[20].h = 349;

    jumpClips[21].x = 1180;
    jumpClips[21].y = 5798;
    jumpClips[21].w = 236;
    jumpClips[21].h = 349;


}

void Player::Jump(SDL_Renderer* renderer, const double angle, SDL_RendererFlip flip)
{

     SDL_Rect* currentClip = &jumpClips[ jumpFrame / 22];

     //Set rendering space and render to screen
    SDL_Rect renderQuad;
    if (jumpFrame == 70 || jumpFrame == 84 || jumpFrame == 98 || jumpFrame == 112 || jumpFrame == 126)
    {
        renderQuad.x = position -> getX();
        renderQuad.y = position -> getY() + 120 - (jumpHeight);
    }
    else
    {
        renderQuad.x = position -> getX();
        renderQuad.y = position -> getY() + 120;
    }
    //renderQuad.x = position -> getX();
    //renderQuad.y = position -> getY() + 120;

    //Set clip rendering dimensions
    if( currentClip != NULL )
    {
        renderQuad.w = 150;
        renderQuad.h = 200;
    }

    //Render to screen
    playerTexture -> Render(renderer,currentClip, &renderQuad, angle , flip );
    //SDL_RenderCopy( renderer, texture1, currentClip, &renderQuad );
    jumpFrame = jumpFrame + 14;
    if (jumpFrame /22>= 22)
    {
        jumpFrame = 0;

    }
    //SDL_RenderPresent(renderer);
}
