#include "Cloud.h"

Cloud::Cloud(LTexture* texture)
{
    cloudTexture = texture;
    srcRect.x = 0;
    srcRect.y = 0;
    srcRect.w = 317;
    srcRect.h = 239;
}

Cloud::~Cloud()
{
    //dtor
}

void Cloud::Render(SDL_Renderer* renderer, SDL_Rect destRect)
{
    cloudTexture -> Render(renderer, &srcRect, &destRect, 0, SDL_FLIP_NONE);
}
