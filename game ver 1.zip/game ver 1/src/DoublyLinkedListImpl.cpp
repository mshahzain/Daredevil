#include "DoublyLinkedListImpl.h"

DoublyLinkedListImpl::DoublyLinkedListImpl()
{
    //ctor
}

DoublyLinkedListImpl::~DoublyLinkedListImpl()
{
    //dtor
}
