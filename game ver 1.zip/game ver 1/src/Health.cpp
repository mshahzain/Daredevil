#include "Health.h"

Health::Health()
{
    healthDecrement = 5;
    healthIncrement = 5;

    outerRect.x = 10;
    outerRect.y = 10;
    outerRect.w = 200;
    outerRect.h = 30;

    innerRect.x = 12;
    innerRect.y = 12;
    innerRect.w = 196;
    innerRect.h = 26;
}



void Health::Render(SDL_Renderer* renderer)
{
    SDL_SetRenderDrawColor(renderer, 0,0,0,0);
    SDL_RenderDrawRect(renderer, &outerRect);
    SDL_SetRenderDrawColor(renderer, 0xFF, 0,0,0);
    SDL_RenderFillRect(renderer, &innerRect);
}
void Health::DecreaseHealth()
{
    innerRect.w -= healthDecrement;
}

void Health::IncreaseHealth()
{
    innerRect.w += healthIncrement;
}
