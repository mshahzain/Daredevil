#include "Building.h"
const int SCREEN_WIDTH = 1280;
const int SCREEN_HEIGHT = 720;
Building::Building(LTexture* texture)
{
    buildingTexture = texture;
    camera.x = 0;
    camera.y = 0;
    camera.w = SCREEN_WIDTH;
    camera.h = SCREEN_HEIGHT;
}

Building::~Building()
{
    //dtor
}

void Building::IncreaseX()
{
    camera.x += buildingVelocity;
}

void Building::DecreaseX()
{
    camera.x -= buildingVelocity;
}

void Building::Render(SDL_Renderer* renderer)
{
    buildingTexture -> Render(renderer, &camera, NULL, 0, SDL_FLIP_NONE);
}
