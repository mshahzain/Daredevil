#include "Point.h"

void Point::setX(int val)
{
    x = val;
}

void Point::setY(int val)
{
    y = val;

}

int Point::getX()
{
    return x;
}

int Point::getY()
{
    return y;
}
